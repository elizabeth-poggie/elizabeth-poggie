# Warm up

Getting Comfortable with Chrome Dev Tools

Follow the tutorial as outline by https://developer.chrome.com/docs/devtools/css/ 

This will help you further practice editing styles directly in browser.

